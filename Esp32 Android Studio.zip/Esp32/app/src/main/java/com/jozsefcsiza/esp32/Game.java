package com.jozsefcsiza.esp32;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.VibrationEffect;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.io.IOException;

public class Game extends MainActivity{
    static String buttonTag = "";
    static GradientDrawable buttonDrawable, touchDrawable;
    static int buttonWH = 110, spacer = 20, bottomPadding = 50, downX, downY, moveX, moveY, stepValue, imageWidthHeight;
    static int touchColor = Color.rgb(113, 128, 147);
    static float textSize;
    static boolean isDown, isBrightness, isResumed;
    static Handler handler;
    static Runnable runnable;

    static void DrawGameMainWindow() {
        isResumed = false;
        isDown = false;
        isBrightness = false;
        stepValue = 1 ; //(int)(1 * density);
        imageWidthHeight = (int) ((buttonWH * density) / 1.75);
        textSize = 16 * density;
        CreateDrawables();

        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.MATCH_PARENT);
        params.leftMargin = 0;
        params.topMargin = 0;

        gameLayout = new LinearLayout(context);
        mainRelativeLayout.addView(gameLayout, params);
        gameLayout.setBackgroundColor(gameBackgroundColor);
        gameLayout.setGravity(Gravity.CENTER | Gravity.BOTTOM);
        gameLayout.setOrientation(LinearLayout.VERTICAL);

        params = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.MATCH_PARENT);
        params.leftMargin = 0;
        params.topMargin = (int)(50 * density);

        gameTextView = new TextView(context);
        mainRelativeLayout.addView(gameTextView, params);
        gameTextView.setBackgroundColor(Color.TRANSPARENT);
        gameTextView.setGravity(Gravity.TOP | Gravity.LEFT);
        gameTextView.setTextAppearance(R.style.TextAppearance_AppCompat_Medium);
        gameTextView.setTextColor(mainTextColor);
        UpdateGameTextView();

        //Up layout draw
        LinearLayout lLayout = new LinearLayout(context);
        LinearLayout.LayoutParams lLParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, (int) (buttonWH * density) * 2 + (int) (spacer * density));
        lLParams.gravity = Gravity.CENTER;

        gameLayout.addView(lLayout, lLParams);
        lLayout.setGravity(Gravity.CENTER);

        //Left button draw
        AddButtons(lLayout, buttonDrawable, (int) (buttonWH * density), (int) (buttonWH * density), BT_GAME_MOVE_LEFT, true, R.drawable.left);

        //Rotate button draw
        AddButtons(lLayout, buttonDrawable, (int) (buttonWH * density), (int) (buttonWH * density), BT_GAME_PLAY, true, R.drawable.play);

        //Right button draw
        AddButtons(lLayout, buttonDrawable, (int) (buttonWH * density), (int) (buttonWH * density), BT_GAME_MOVE_RIGHT, false, R.drawable.right);

        //Down layout draw
        lLayout = new LinearLayout(context);
        lLParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, (int) (buttonWH * density) / 4 + (int) (spacer * density));
        lLParams.gravity = Gravity.CENTER;

        gameLayout.addView(lLayout, lLParams);
        lLayout.setGravity(Gravity.CENTER);

        SetNavigationBarColor(gameBackgroundColor);
        setStatusBarColor(gameBackgroundColor);

        onDownThread();
    }

    static void UpdateGameTextView()
    {
        String text = "   Current score: " + Esp32Data.GameCurrentScore
                + "\n"
                + "   High score: " + Esp32Data.GameHighScore
                ;
        gameTextView.setText(text);;
    }

    static void AddButtons(LinearLayout lLayout, GradientDrawable drawable, int w, int h, String tag, boolean isNeedSpacer, int imageResource)
    {
        LinearLayout mainLayout = new LinearLayout(context);
        LinearLayout.LayoutParams lLParams = new LinearLayout.LayoutParams(w, 2 * h);
        lLParams.gravity = Gravity.CENTER;

        lLayout.addView(mainLayout, lLParams);
        mainLayout.setGravity(Gravity.CENTER);

        LinearLayout iViewLayout = new LinearLayout(context);
        lLParams = new LinearLayout.LayoutParams(w, h);
        lLParams.gravity = Gravity.CENTER;

        mainLayout.addView(iViewLayout, lLParams);
        iViewLayout.setGravity(Gravity.CENTER);
        if (tag != null) {
            iViewLayout.setBackground(drawable);
        }

        ImageView iView = new ImageView(context);
        lLParams = new LinearLayout.LayoutParams(imageWidthHeight, imageWidthHeight);
        lLParams.gravity = Gravity.CENTER;

        iViewLayout.addView(iView, lLParams);
        if (tag != null) {
            iView.setImageBitmap(GetImageViewBitmap(imageResource));
        }
        iView.setTag(tag);

        if (tag != null) {
            SetontouchListener(mainLayout, iViewLayout, iView, tag);
        }

        //spacer
        if (isNeedSpacer) {
            iView = new ImageView(context);
            lLParams = new LinearLayout.LayoutParams((int) (spacer * density), (int) (buttonWH * density));
            lLParams.gravity = Gravity.CENTER;

            lLayout.addView(iView, lLParams);
        }
    }

    static Bitmap GetImageViewBitmap(int imageResource) {
        Bitmap bitmap = null;
        try
        {
            Drawable sourceDrawable = context.getResources().getDrawable(imageResource);
            bitmap = ((BitmapDrawable) sourceDrawable).getBitmap();
            bitmap = Bitmap.createScaledBitmap(bitmap, imageWidthHeight, imageWidthHeight, true);
        }
        catch(OutOfMemoryError E)
        {
            System.gc();

            try
            {
                Drawable sourceDrawable = context.getResources().getDrawable(imageResource);
                bitmap = ((BitmapDrawable) sourceDrawable).getBitmap();
                bitmap = Bitmap.createScaledBitmap(bitmap, imageWidthHeight, imageWidthHeight, true);
            }
            catch(OutOfMemoryError ER)
            {
                System.gc();
            }
        }
        return bitmap;
    }

    static void SetontouchListener (final LinearLayout layout, final LinearLayout iViewLayout, final ImageView iView, final String tag)
    {
        layout.setOnTouchListener (new View.OnTouchListener()
        {
            public boolean onTouch(View v, MotionEvent event) {

                int action = event.getAction();
                switch (action){
                    case MotionEvent.ACTION_DOWN:
                        iView.setScaleX(0.75f);
                        iView.setScaleY(0.75f);
                        buttonTag = tag;
                        isDown = true;
                        iViewLayout.setBackground(null);
                        iViewLayout.setBackground(touchDrawable);
                        //try {
                            //mVibrator.vibrate(VibrationEffect.createOneShot(VIBRATE_DURATION, VibrationEffect.DEFAULT_AMPLITUDE));
                        //} catch (Exception e){
                            //mVibrator.vibrate(VIBRATE_DURATION);
                        //}
                        break;
                    case MotionEvent.ACTION_UP:
                        buttonTag = "";
                        iView.setScaleX(1.0f);
                        iView.setScaleY(1.0f);
                        isDown = false;
                        iViewLayout.setBackground(null);
                        iViewLayout.setBackground(buttonDrawable);
                        try {
                            myBluetooth.write(tag);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        break;
                    case MotionEvent.ACTION_CANCEL:
                        buttonTag = "";
                        iView.setScaleX(1.0f);
                        iView.setScaleY(1.0f);
                        isDown = false;
                        iViewLayout.setBackground(null);
                        iViewLayout.setBackground(buttonDrawable);
                        break;
                }
                return true;
            }
        });
    }

    static void onDownThread(){
        handler = new Handler();

        runnable = new Runnable() {
            public void run() {
                if (isDown) {
                    try {
                        if (!buttonTag.equals(BT_GAME_PLAY) && !buttonTag.equals("")) {
                            myBluetooth.write(buttonTag);
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                handler.postDelayed(this, 0);
            }
        };

        handler.postDelayed(runnable, 0);
    }

    static void KillOnDownThread(){
        if (handler != null) {
            try
            {
                handler.removeCallbacks(runnable);
            } catch (Exception e){ };
        }
    }

    static void CreateDrawables()
    {
        float radius = (buttonWH * density) / 6.0f;
        buttonDrawable = new GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                new int[] {Color.rgb(52, 73, 94), Color.rgb(52, 73, 94)});
        buttonDrawable.setCornerRadii(
                new float[] {
                        radius, radius,
                        radius, radius,
                        radius, radius,
                        radius, radius});
        buttonDrawable.setStroke((int)(0.75 * density), mainTextColor);

        touchDrawable = new GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                new int[] {touchColor, touchColor});
        touchDrawable.setCornerRadii(
                new float[] {
                        radius, radius,
                        radius, radius,
                        radius, radius,
                        radius, radius});
    }
}
