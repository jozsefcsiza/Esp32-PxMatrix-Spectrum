package com.jozsefcsiza.esp32;

public class Esp32Data {
    public static int SmoothSpectrum = 0;
    public static int Brightness = 50;
    public static int Gain = 30;
    public static int Squelch = 0;
    public static int GameCurrentScore = 0;
    public static int GameHighScore = 0;

    static void DefaultValues() {
        SmoothSpectrum = 0;
        Brightness = 50;
        Gain = 30;
        Squelch = 0;
        GameCurrentScore = 0;
        GameHighScore = 0;
    }
}
