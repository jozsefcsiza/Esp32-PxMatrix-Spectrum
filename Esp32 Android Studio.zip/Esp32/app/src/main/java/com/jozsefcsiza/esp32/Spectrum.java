package com.jozsefcsiza.esp32;

import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import java.io.IOException;

public class Spectrum extends MainActivity{
    static String brightnessString, gainString, squelchString;
    static int w, h, touchColor = Color.rgb(113, 128, 147), downY, moveY;
    static GradientDrawable buttonDrawable, touchDrawable;

    static void DrawSpectrumSettings() {
        w = (int)(displayWidth / 1.25);
        h = (int)(50 * density);
        CreateDrawables();
        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.MATCH_PARENT);
        params.leftMargin = 0;
        params.topMargin = 0;

        spectrumLayout = new LinearLayout(context);
        mainRelativeLayout.addView(spectrumLayout, params);
        spectrumLayout.setBackgroundColor(spectrumBackgroundColor);
        spectrumLayout.setGravity(Gravity.CENTER);
        spectrumLayout.setOrientation(LinearLayout.VERTICAL);

        DrawMenuElement("NEXT PATTERN", BT_SPECTRUM_NEXT_PATTERN);
        DrawSpacer();
        DrawMenuElement("SMOOTH SPECTRUM", BT_SPECTRUM_SMOOTH);
        DrawSpacer();
        DrawMenuSeekBar("   BRIGHTNESS" + " - " + Integer.toString(Esp32Data.Brightness), BT_SPECTRUM_BRIGHTNESS, 0, 100);
        DrawSpacer();
        DrawMenuSeekBar("   GAIN" + " - " + Integer.toString(Esp32Data.Gain), BT_SPECTRUM_GAIN, -2, 120);
        DrawSpacer();
        DrawMenuSeekBar("   SQUELCH" + " - " + Integer.toString(Esp32Data.Squelch), BT_SPECTRUM_SQUELCH, 0, 30);
        DrawSpacer();
        DrawMenuElement("RESET (DEFAULTS)", BT_SPECTRUM_RESET);

        SetNavigationBarColor(spectrumBackgroundColor);
        setStatusBarColor(spectrumBackgroundColor);
    }
    static void DrawMenuElement(String text, String tag) {
        float textSize = 5f * density;
        TextView tView = new TextView(context);
        LinearLayout.LayoutParams lLParams = new LinearLayout.LayoutParams(w, h);
        lLParams.gravity = Gravity.CENTER;

        spectrumLayout.addView(tView, lLParams);
        tView.setGravity(Gravity.CENTER);
        tView.setBackground(buttonDrawable);
        tView.setTextSize(textSize);
        tView.setTextColor(mainTextColor);
        tView.setText(text);

        SetontouchListener(tView, tag);
    }

    static void DrawMenuSeekBar(String text, String tag, int minValue, int maxValue) {
        float textSize = 4f * density;

        LinearLayout layout = new LinearLayout(context);
        LinearLayout.LayoutParams lLParams = new LinearLayout.LayoutParams(w, (int) (h / 1.75));
        lLParams.gravity = Gravity.CENTER;
        spectrumLayout.addView(layout, lLParams);

        TextView tView = new TextView(context);
        lLParams = new LinearLayout.LayoutParams(w, (int) (h / 1.75));
        lLParams.gravity = Gravity.BOTTOM | Gravity.LEFT;

        layout.addView(tView, lLParams);
        tView.setTextSize(textSize);
        tView.setTextColor(mainTextColor);
        tView.setText(text);
        tView.setTag(tag + "TextView");

        SeekBar seekBar = new SeekBar(context);
        lLParams = new LinearLayout.LayoutParams(w, (int) (h / 2.0));
        lLParams.gravity = Gravity.CENTER;

        spectrumLayout.addView(seekBar, lLParams);
        seekBar.getProgressDrawable().setColorFilter(new PorterDuffColorFilter(mainTextColor, PorterDuff.Mode.MULTIPLY));
        seekBar.getThumb().setColorFilter(mainTextColor, PorterDuff.Mode.SRC_IN); //Circle Color
        seekBar.setMin(minValue);
        seekBar.setMax(maxValue);
        seekBar.setTag(tag + "SeekBar");
        if (tag.equals(BT_SPECTRUM_BRIGHTNESS)) {
            seekBar.setProgress(Esp32Data.Brightness);
        } else if (tag.equals(BT_SPECTRUM_GAIN)) {
            seekBar.setProgress(Esp32Data.Gain);
        } else if (tag.equals(BT_SPECTRUM_SQUELCH)) {
            seekBar.setProgress(Esp32Data.Squelch);
        }

        SetontouchListenerSeekBar(seekBar, tView, text, tag);
    }

    static void DrawSpacer() {
        TextView tView = new TextView(context);
        LinearLayout.LayoutParams lLParams = new LinearLayout.LayoutParams(w, h / 2);
        lLParams.gravity = Gravity.CENTER;

        spectrumLayout.addView(tView, lLParams);
    }

    static void CreateDrawables() {
        float radius = h / 5.0f;
        buttonDrawable = new GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                new int[] {Color.TRANSPARENT, Color.TRANSPARENT});
        buttonDrawable.setCornerRadii(
                new float[] {
                        radius, radius,
                        radius, radius,
                        radius, radius,
                        radius, radius});
        buttonDrawable.setStroke((int)(0.5 * density), mainTextColor);

        touchDrawable = new GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                new int[] {touchColor, touchColor});
        touchDrawable.setCornerRadii(
                new float[] {
                        radius, radius,
                        radius, radius,
                        radius, radius,
                        radius, radius});
        touchDrawable.setStroke((int)(0.5 * density), mainTextColor);
    }

    static void SetontouchListener (final TextView textView, final String tag) {
        textView.setOnTouchListener (new View.OnTouchListener()
        {
            public boolean onTouch(View v, MotionEvent event) {

                int action = event.getAction();
                switch (action){
                    case MotionEvent.ACTION_DOWN:
                        downY = (int) event.getRawY();
                        textView.setBackground(null);
                        textView.setBackground(touchDrawable);
                        Vibrate();
                        break;
                    case MotionEvent.ACTION_MOVE:
                        moveY = (int) event.getRawY();
                        break;
                    case MotionEvent.ACTION_UP:
                        textView.setBackground(null);
                        textView.setBackground(buttonDrawable);
                        if (Math.abs(moveY - downY) < h / 2) {
                            try {
                                myBluetooth.write(tag);
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                            if (tag.equals(BT_SPECTRUM_RESET)) {
                                Esp32Data.DefaultValues();
                                RefreshSeekbar(BT_SPECTRUM_BRIGHTNESS, Esp32Data.Brightness, "   BRIGHTNESS");
                                RefreshSeekbar(BT_SPECTRUM_GAIN, Esp32Data.Gain, "   GAIN");
                                RefreshSeekbar(BT_SPECTRUM_SQUELCH, Esp32Data.Squelch, "   SQUELCH");
                            }
                        }
                        break;
                    case MotionEvent.ACTION_CANCEL:
                        textView.setBackground(null);
                        textView.setBackground(buttonDrawable);
                        break;
                }
                return true;
            }
        });
    }

    static void SetontouchListenerSeekBar (final SeekBar seekBar, final TextView tView, final String mainText, final String tag) {
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                // TODO Auto-generated method stub
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                // TODO Auto-generated method stub
            }

            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                // TODO Auto-generated method stub
                Vibrate();
                if (tag.equals(BT_SPECTRUM_BRIGHTNESS)) {
                    Esp32Data.Brightness = progress;
                    tView.setText("   BRIGHTNESS" + " - " + Integer.toString(progress));
                } else if (tag.equals(BT_SPECTRUM_GAIN)) {
                    Esp32Data.Gain = progress;
                    tView.setText("   GAIN" + " - " + Integer.toString(progress));
                } else if (tag.equals(BT_SPECTRUM_SQUELCH)) {
                    Esp32Data.Squelch = progress;
                    tView.setText("   SQUELCH" + " - " + Integer.toString(progress));
                }
                try {
                    myBluetooth.write(tag + Integer.toString(progress));
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    static void RefreshSeekbar(String tag, int progress, String text) {
        try {
            SeekBar seekBar = (SeekBar) spectrumLayout.findViewWithTag(tag + "SeekBar");
            seekBar.setProgress(progress);
            TextView tView = (TextView) spectrumLayout.findViewWithTag(tag + "TextView");
            tView.setText(text + " - " + Integer.toString(progress));
        } catch (Exception e) {};
    }
}
